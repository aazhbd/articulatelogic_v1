<?php
/**
* An open source web application development framework for PHP 5 and above.
*
* @author        ArticulateLogic Labs
* @author        Abdullah Al Zakir Hossain, Email: aazhbd@yahoo.com 
* @author        Syeda Tasneem Rumy, Email: tasneemrumy@gmail.com
* @author        Abdullah Al Zakir Hossain, Email: aazhbd@yahoo.com
* @copyright     Copyright (c)2009-2010 ArticulateLogic Labs, creative software engineering
* @license       www.articulatelogic.com/a/privacy,  www.articulatelogic.com/a/terms
* @link          http://www.articulatelogic.com
* @since         Version 1.0
*  
*/

class Dblib
{
    var $err;
    var $dbh;

	function Dblib($host, $dbname, $user, $pass)
	{
        $this->err = "";

        try {
            $this->dbh = mysql_connect($host, $user, $pass) or die("Can't connect: ".mysql_error());
            mysql_select_db($dbname, $this->dbh) or die("Database Missing");
        }
        catch (Exception $e) {
            $this->err = "Error occured: " . $e->getMessage();
        }
	}
    
    function executeQuery($query)
    {
        $result = array();
        
        try{
            $q = stripslashes(mysql_real_escape_string($query));
            
            if($r = mysql_query($q))
                while($line = mysql_fetch_array($r, MYSQL_ASSOC))
                    $result[] = $line;
            else
                return mysql_error();
        }
        catch(Exception $e){
            $this->err = "Error occured: " . $e->getMessage();
            return false;
        }
        
        return $result;
    }
    
    function executeNonQuery($query)
    {
        try{
            $r = mysql_query($query);
        }
        catch(Exception $e)
        {
            $this->err = "Error occured: " . $e->getMessage();
            return false;
        }
        
        return true;
    }
    
    function selectData($query)
    {
        $result = array();
        
        try{
            $q = stripslashes(mysql_real_escape_string($query));
            
            if($r = mysql_query($q))
                while($line = mysql_fetch_array($r, MYSQL_ASSOC))
                    $result[] = $line;
            else
                $this->err = mysql_error();
        }
        catch(Exception $e){
            $this->err = "Error occured: " . $e->getMessage();
            return false;
        }
        
        return $result;
    }
    
    function insertData($table , $fields, $values)
    {
        $n = count($fields);
        $m = count($values);
        
        if($n != $m) return false;
        
        for($i = 0; $i < $m ; $i++)
            $values[$i] = mysql_real_escape_string($values[$i]);
        
        try{            
            $query = "insert into `" . $table . "`(";

            for($i = 0; $i < $n; $i++)
            {
                $query .= "`" . $fields[$i] . "`";
                if($i != ($n - 1)) $query .= ",";
            }
            
            $query .= ") values(";
            
            for($i = 0; $i < $m; $i++)
            {
                $query .= "'" . $values[$i] . "'";
                if($i != ($m - 1)) $query .= ",";
            }
            $query .= ")";
            
            if($r = mysql_query($query))
                return true;
            else
                $this->err = mysql_error();
        }
        catch(Exception $e)
        {
            $this->err = "Error occured : " . $e->getMessage();
            return false;
        }
    }
    
    function updateData($query)
    {
        $q = trim($query);
        $p = stripos($q, "update");
        if($p === false){
            $this->err = "invalid request";
            return false;
        }
        
        try{
            if($r = mysql_query($q))
                return true;
            else
            {
                $this->err = mysql_error();
                return false;
            }
        }
        catch(Exception $e)
        {
            $this->err = "Error occured : " . $e->getMessage();
            return false;
        }
        
        return true;
    }
    
    function deleteData($query)
    {
        $q = trim($query);
        $p = stripos($q, "delete");
        if($p === false)
        {
            $this->err = "invalid request";
            return false;
        }
        
        if(stripos($q, "where") === false) return "invalid request";
        
        try{
            if($r = mysql_query($q))
                return true;
            else{
                $this->err = mysql_error();
                return false;
            }
        }
        catch(Exception $e)
        {
            $this->err = "error occured : " . $e->getMessage();
            return false;
        }
        
        return true;
    }
    
    function closeDB()
    {
        $this->dbh = null;
    }
}

?> 
