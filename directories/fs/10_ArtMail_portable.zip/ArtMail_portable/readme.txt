Copyright (c) 2009-2010, ArticulateLogic Labs, creative software engineering
www.articulatelogic.com

All rights reserved.



ArtMail (Portable version)
A smart eMail Client Application

Version 1.0



Welcome, to ArtMail.

ArtMail is a freely distributable, simple and elegant eMail Client Application 
for sending and receiving emails from POP3 mail server for the Windows Operating 
System platform.

--
ArticulateLogic Team





System Requirements
-------------------------------------------------------------------------------------

1. Dot NET framework 2.0 or higher.
2. Windows OS: Windows 2000, Windows XP, Windows Vista, Windows 7.
3. At least 250 Mega Bytes of free hard disk space.
4. Pentium III or higher processor speed.


Installation:
-------------------------------------------------------------------------------------

1. Install .Net framework 2.0 or higher.

2. Unzip the contents of this folder and run the MailClient.exe



Final Notes:
-----------------------------------------------------------------------------------
If you have any suggestions, ideas, comments, or if you found a bug, let us know. Email: web@articulatelogic.com

You may also join our team and contribute your codes for improvement or bug fixes. You are most welcome.
You may submit your own codes to our website www.articulatelogic.com. We shall host your software freely.