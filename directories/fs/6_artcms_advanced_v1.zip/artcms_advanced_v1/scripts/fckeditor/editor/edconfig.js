
FCKConfig.AutoDetectLanguage = true;
FCKConfig.ToolbarSets["ArticleToolbar"] = [
['Undo','Redo','-','Find','Replace','-','RemoveFormat','JustifyLeft','JustifyCenter','JustifyRight','JustifyFull','Link','Unlink', 'Table','Rule','Smiley','SpecialChar','SelectAll','Cut','Copy','Paste','PasteText','PasteWord','Source'],

['TextColor', 'BGColor', 'Bold','Italic','Underline', 'StrikeThrough','-','Subscript','Superscript','-' ,'OrderedList', 'UnorderedList','FontFormat', 'FontName','FontSize'],
] ;
