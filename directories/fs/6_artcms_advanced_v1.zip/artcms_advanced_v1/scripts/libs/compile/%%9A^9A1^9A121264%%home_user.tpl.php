<?php /* Smarty version 2.6.26, created on 2010-02-22 17:46:22
         compiled from home_user.tpl */ ?>
<?php if ($this->_tpl_vars['subinfo'] != null): ?>
    <div><?php echo $this->_tpl_vars['subinfo']; ?>
</div>
<?php endif; ?>
<?php if ($this->_tpl_vars['login_msg'] != null): ?>
    <div><?php echo $this->_tpl_vars['login_msg']; ?>
</div>
<?php endif; ?>