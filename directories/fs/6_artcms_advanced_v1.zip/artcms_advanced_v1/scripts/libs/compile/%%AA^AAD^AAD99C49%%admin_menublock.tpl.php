<?php /* Smarty version 2.6.26, created on 2010-02-22 00:37:58
         compiled from admin_menublock.tpl */ ?>
<div class="adminbox" align="middle">
    <a href="<?php echo @URL; ?>
/manage/users" class="adminblock" title="Manage Users"><img src="<?php echo @URL; ?>
/interface/images/users.png" alt="Users" style="width: 128px; "/> Manage Users</a>
    <a href="<?php echo @URL; ?>
/manage/categories" class="adminblock" title="Manage Categories"><img src="<?php echo @URL; ?>
/interface/images/category.png" alt="Categories" style="width: 128px; "/>Manage Categories</a>
    <a href="<?php echo @URL; ?>
/manage/articles" class="adminblock" title="Manage Articles"><img src="<?php echo @URL; ?>
/interface/images/article.png" alt="Articles" style="width: 128px; " />Manage Articles</a>
</div>