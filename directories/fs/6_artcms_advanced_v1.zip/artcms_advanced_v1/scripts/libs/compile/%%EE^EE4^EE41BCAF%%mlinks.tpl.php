<?php /* Smarty version 2.6.26, created on 2010-02-22 00:37:50
         compiled from subtpl/mlinks.tpl */ ?>

<link href="<?php echo @URL; ?>
/interface/css/zstyle.css" rel="stylesheet" type="text/css" media="screen" />
<link href="<?php echo @URL; ?>
/interface/css/forms.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo @URL; ?>
/scripts/css/ui-lightness/jquery-ui-1.7.2.custom.css" />
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo @URL; ?>
/scripts/css/dialog/jquery.alerts.css" />
<!--[if lte IE 6]>
<link href="<?php echo @URL; ?>
interface/css/msie.css" type="text/css" rel="stylesheet" media="screen,projection" />
<![endif]-->