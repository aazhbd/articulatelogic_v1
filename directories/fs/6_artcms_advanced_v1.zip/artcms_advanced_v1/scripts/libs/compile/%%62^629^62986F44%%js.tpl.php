<?php /* Smarty version 2.6.26, created on 2010-02-22 00:37:50
         compiled from subtpl/js.tpl */ ?>

<script type="text/javascript" src="<?php echo @URL; ?>
/scripts/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php echo @URL; ?>
/scripts/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo @URL; ?>
/scripts/js/jquery-ui-1.7.2.custom.min.js"></script>
<script type="text/javascript" src="<?php echo @URL; ?>
/scripts/js/jquery.alerts.js" ></script>