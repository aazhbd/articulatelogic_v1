<?php

$routes = array(
    'urls' => array(
        '' => '/controller/Views/viewCustom',
        '/home' => '/controller/Views/viewHome'
    )
);

return $routes['urls'];
