<?php /* Smarty version 2.6.26, created on 2010-03-01 21:51:41
         compiled from subtpl/footer.tpl */ ?>
<p>
    &copy; 2009 <a href="http://www.articulatelogic.com/">ArticulateLogic.com</a>
    | Design: <a href="mailto:aazhbd@yahoo.com">aazhbd</a>
    | <a href="<?php echo @URL; ?>
a/privacy">Privacy Policy</a>
    | <a href="<?php echo @URL; ?>
a/termsofuse">Terms of Use</a>
    | <a href="<?php echo @URL; ?>
a/services">Services</a>
    | <a href="<?php echo @URL; ?>
a/contact">Contact</a>
</p>