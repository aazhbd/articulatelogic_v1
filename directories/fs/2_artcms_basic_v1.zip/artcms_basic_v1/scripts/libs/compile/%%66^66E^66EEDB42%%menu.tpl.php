<?php /* Smarty version 2.6.26, created on 2010-03-01 21:51:41
         compiled from subtpl/menu.tpl */ ?>

<ul id="nav">
    <li><a href="<?php echo @URL; ?>
home">Home</a></li>

    <li><a href="<?php echo @URL; ?>
a/Lorem_Ipsum">Dummy Links</a>
        <ul>
            <li><a href="<?php echo @URL; ?>
a/Lorem_Ipsum">Dummy Link 1</a></li>
            <li><a href="<?php echo @URL; ?>
a/Lorem_Ipsum">Dummy Link 2</a></li>
        </ul>
    </li>
    <li><a href="<?php echo @URL; ?>
a/contact">Contact</a></li>
    <li><a href="<?php echo @URL; ?>
a/conveylive">ConveyLive</a></li>
</ul>